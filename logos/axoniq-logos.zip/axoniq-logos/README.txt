Axoniq logos, exported from the Figma "Logos" component set.
Names: axoniq-<product>-<layout>-<color>
  product: company, platform, framework, server, insights, discuss, academy
  layout:  icon, horizontal, vertical-left, vertical-center, vertical-right
  color:   original (light backgrounds), original-alt (dark backgrounds), white, black
svg/     vector files
png/1x/  transparent PNG at the Figma frame size
png/4x/  transparent PNG at four times that size, for print
Rules: use as is, resize only with the aspect ratio kept, clear space equal to the icon height.
The icon alone is for internal use. Guidelines: https://axoniq-brandzone.vercel.app/logos
